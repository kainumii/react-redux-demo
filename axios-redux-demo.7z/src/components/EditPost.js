import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
// import { useHistory } from "react-router-dom";
import { useNavigate, useParams } from "react-router-dom";
import { postUpdated } from "../features/postsSlice";

import {
  Button,
  Typography,
  Container,
  TextField,
  ButtonGroup,
} from "@mui/material";

export const EditPostForm = ({ match }) => {
  let navigate = useNavigate();
  let params = useParams();

  var id = params.postId;
  //const { postId } = match.params;

  const post = useSelector((state) =>
    state.postsRed.data.find((post) => post.id == id)
  );

  const [title, setTitle] = useState(post.title);
  const [content, setContent] = useState(post.body);

  const dispatch = useDispatch();
  //   const history = useHistory();

  const onTitleChanged = (e) => setTitle(e.target.value);
  const onContentChanged = (e) => setContent(e.target.value);

  const onSavePostClicked = () => {
    if (title && content) {
      dispatch(postUpdated({ id: id, title, content }));
      //   history.push(`/posts/${postId}`);
      navigate(`/posts/${id}`);
    }
  };

  const onCancelClicked = () => {
    navigate(`/posts/${id}`);
  };

  return (
    // <section>
    //   <h2>Edit Post</h2>
    //   <form>
    //     <label htmlFor="postTitle">Post Title:</label>
    //     <input
    //       type="text"
    //       id="postTitle"
    //       name="postTitle"
    //       placeholder="What's on your mind?"
    //       value={title}
    //       onChange={onTitleChanged}
    //     />
    //     <label htmlFor="postContent">Content:</label>
    //     <textarea
    //       id="postContent"
    //       name="postContent"
    //       value={content}
    //       onChange={onContentChanged}
    //     />
    //   </form>
    //   <button type="button" onClick={onSavePostClicked}>
    //     Save Post
    //   </button>
    // </section>

    <>
      <Container
        maxWidth="lg"
        sx={{
          m: 3,
          display: "flex",
          alignItems: "center",
          justifyContent: "left",
          flexDirection: "column",
          height: "100vh",
        }}
      >
        <Typography
          sx={{
            textAlign: "center",
          }}
          variant="h6"
        >
          Otsikko
        </Typography>
        <TextField
          value={title}
          onChange={onTitleChanged}
          sx={{ width: "90%" }}
        ></TextField>

        <Typography
          sx={{
            textAlign: "center",
          }}
          variant="h6"
        >
          Sisältö
        </Typography>
        <TextField
          multiline={true}
          value={content}
          onChange={onContentChanged}
          sx={{ width: "90%" }}
        ></TextField>

        <ButtonGroup
          variant="text"
          sx={{ m: 2 }}
          aria-label="text button group"
        >
          <Button onClick={onSavePostClicked} size="large">
            Save Post
          </Button>{" "}
          <Button onClick={onCancelClicked} size="large">
            Cancel
          </Button>
        </ButtonGroup>
      </Container>
    </>
  );
};
