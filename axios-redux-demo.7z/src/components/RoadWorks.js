import React from "react";
import { Card, CardContent, Typography } from "@mui/material";
import { useState, useEffect } from "react";

const QUERY_GET_ALL_ROADWORKS = `query GetAllRoadworks {
  roadworks {
    id
    roadworkId
    severity
    status
    startTime
    endTime
    description {
      fi
    }
    geojson
  }
}`;

const RoadWorks = () => {
  const [roadWorks, setRoadWorks] = useState([]);

  useEffect(() => {
    fetch("https://api.oulunliikenne.fi/proxy/graphql", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: QUERY_GET_ALL_ROADWORKS }),
    })
      .then((response) => response.json())
      .then((data) => {
        setRoadWorks(data.data.roadworks);
        console.log(data.data.roadworks);
      });
  }, []);

  return (
    <>
      <div>
        {roadWorks.map((item) => {
          return (
            <Card
              sx={{
                minWidth: 275,
                backgroundColor: "lightgray",
                border: 1,
                borderColor: "black",
                m: "24px",
              }}
            >
              <CardContent>
                <Typography variant="body2">
                  {item.description["fi"]}
                </Typography>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </>
  );
};

export default RoadWorks;
