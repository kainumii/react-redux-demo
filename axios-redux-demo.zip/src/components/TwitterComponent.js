import React from "react";

const TwitterComponent = () => {
  return <>Twitter</>;
};

export default TwitterComponent;
