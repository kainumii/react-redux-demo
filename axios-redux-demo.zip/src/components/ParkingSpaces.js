import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import React, { useEffect } from "react";
import { useState } from "react";
import { Typography } from "@mui/material";
import Paper from "@mui/material/Paper";
import { styled } from "@mui/material/styles";

const QUERY = `query GetAllCarParks {
  carParks {
    carParkId
    name
    lat
    lon
    maxCapacity
    spacesAvailable
  }
}`;

const ParkingSpaces = () => {
  const [parkingSpaces, setParkingSpaces] = useState([]);

  useEffect(() => {
    fetch("https://api.oulunliikenne.fi/proxy/graphql", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: QUERY }),
    })
      .then((response) => response.json())
      .then((data) => setParkingSpaces(data.data.carParks));
  }, []);

  const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 16,
    },
  }));

  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    "&:nth-of-type(odd)": {
      backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    "&:last-child td, &:last-child th": {
      border: 0,
    },
  }));
  return (
    <>
      <Typography sx={{ m: 3 }} variant="h6">
        GraphQlDemo
      </Typography>
      <Typography sx={{ m: 3 }} variant="body1">
        GraphQL on suunniteltu käytettävän siihen tarkoitetuilla
        ohjelmistokehityspaketeilla jotka sisältävät toimintoja kuten kutsujen
        validointia sekä kutsujen niputtamista. Hakuja voi myös tehdä suoraan
        HTTP POST kutsuilla, milloin itse haku liitetään kutsun body kenttään.
      </Typography>
      <Typography sx={{ m: 3 }} variant="body1">
        Yleisesti käytetyt GraphQL-ohjelmistokehityspaketit:
      </Typography>
      <ul>
        <li>Apollo</li>
        <li>Relay</li>
      </ul>

      <Typography sx={{ m: 3 }} variant="h6">
        Pysäköintitalojen tilatiedot
      </Typography>
      <Typography sx={{ m: 3 }} variant="body1">
        Oulun alueen pysäköintitalot ja ajantasaiset tilatiedot. Oulun kaupungin
        16 pysäköintitalosta on saatavilla tiedot pysäköintipaikkojen määristä
        sekä vapaina olevista paikoista. Tämän lisäksi osasta pysäköintitaloista
        löytyy tiedot pysäköintihinnoista. Tilatietoja päivitetään 5-20 minuutin
        välein pysäköintitalosta riippuen.
      </Typography>

      <TableContainer sx={{ m: 3, width: "95%" }} component={Paper}>
        <Table aria-label="simple table" size="small">
          <TableHead>
            <TableRow>
              <StyledTableCell>Parking Space</StyledTableCell>
              <StyledTableCell align="right">Lat</StyledTableCell>
              <StyledTableCell align="right">Lon</StyledTableCell>
              <StyledTableCell align="right">Max Capacity</StyledTableCell>
              <StyledTableCell align="right">Spaces available</StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {parkingSpaces.map((row) => (
              <StyledTableRow
                key={row.name}
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <StyledTableCell component="th" scope="row">
                  {row.name}
                </StyledTableCell>
                <StyledTableCell align="right">{row.lat}</StyledTableCell>
                <StyledTableCell align="right">{row.lon}</StyledTableCell>
                <StyledTableCell align="right">
                  {row.maxCapacity}
                </StyledTableCell>
                <StyledTableCell align="right">
                  {row.spacesAvailable}
                </StyledTableCell>
              </StyledTableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
};

export default ParkingSpaces;
